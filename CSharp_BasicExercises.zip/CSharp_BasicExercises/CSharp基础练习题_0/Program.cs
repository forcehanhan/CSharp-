﻿/*
 * 时间：
 * 题目：
 * 实现目的：
 * 操作步骤：
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSharp基础练习题_0
{
    class Program
    {
        static void Main(string[] args) {
        }
    }
}
